global.owner = [
  "6282247684638", //ganti nomor owner
  "" //nomor owner kedua kalo ada
]
global.botname = "Sasuke Crash"
global.nomorbot = '6282247684638'
global.urlfoto = 'https://files.catbox.moe/tt3wcm.jpg'

//setting cpanel
global.domain = "https://langgxyz.king-hosting.live"
global.apikey = "ptla_YQ4RuQGtH9P7XnsVL6Mw8q2OSaAKsGWEN7wxZcR2Gwg"
global.capikey = "ptlc_vArplBxk92UX9UkmyOGSFABojzUJhDnjToQ9mxPcE9s"
global.eggsnya = "15"
global.location = "1"
//mess
global.mess = {
 group: '*Fitur Ini Hanya Untuk Didalam Grup*',
 admin: '*Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin*',
 botadmin: "*Bot bukan admin kocak!*",
 owner: '*Fitur Ini Hanya Untuk Owner Bot*',
 premium: '*Fitur Ini Hanya Untuk User Premium*',
 wait: '*Proses, Mohon Tunggu Sebentar...*',
 success: '*Success*'
}

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})